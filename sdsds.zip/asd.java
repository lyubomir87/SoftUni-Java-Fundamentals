import java.util.Scanner;

public class asd {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        message mes = new message();
        for (int i = 0; i < n; i++) {
            String random = mes.randomMessage();
            System.out.println(random);

        }
    }
}
